"""Pro license 验证密钥材料。

安全说明：当前为对称 HMAC 简化实现，密钥内嵌于发行包内，技术上可被提取伪造 key。
对 ¥99 单机工具的威胁模型（网络工程师个人购买、批量备份自用）属可接受风险；
v0.5+ 计划升级 Ed25519 非对称签名（私钥永不随包分发）。
"""
PRO_SECRET = b"netcfg-vault-pro-signing-key-v1-2026"


# Ed25519 license 验证公钥（公开材料，随包分发；对应私钥仅作者持有）
PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAtWosditjkR01OVJ1svcO28roTc3zW1flvfTW4dRkE0s=
-----END PUBLIC KEY-----
"""
